from MarioBros.baseElementos import *
from MarioBros.decorativo import *
from MarioBros.reference import *
from MarioBros.actores import *
from graphics import *
